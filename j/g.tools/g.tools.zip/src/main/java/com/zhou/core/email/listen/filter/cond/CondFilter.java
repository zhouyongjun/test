package com.zhou.core.email.listen.filter.cond;

import com.zhou.core.email.EmailFilter;

public interface CondFilter extends EmailFilter{

}
