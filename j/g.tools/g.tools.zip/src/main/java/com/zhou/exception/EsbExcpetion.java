package com.zhou.exception;

public class EsbExcpetion extends ConsoleException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
