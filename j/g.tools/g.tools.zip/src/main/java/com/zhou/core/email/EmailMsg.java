package com.zhou.core.email;

import java.util.ArrayList;
import java.util.List;
	/**
	 * �ʼ���Ϣ����ʵ����
	 * @author zhouyongjun
	 *
	 */
public class EmailMsg {
	private String hint;
	private List<String> texts;
	
	public EmailMsg(String hint) {
		this.hint = hint;
		texts = new ArrayList<String>();
	}

	public String getHint() {
		return hint;
	}

	public void setHint(String hint) {
		this.hint = hint;
	}
	/**
	 * ��Ϣ���
	 * @return
	 */
	public String toText() {
		if (texts.isEmpty()) return "";
		StringBuffer sb = new StringBuffer();
		for (String text : texts) {
			sb.append(text).append("\n")
			.append("---------------------------------------------------------\n");
		}
		return sb.toString();
	}

	public List<String> getTexts() {
		return texts;
	}

	public void setTexts(List<String> texts) {
		this.texts = texts;
	}

	public void addText(String text) {
		texts.add(text);
	}
	
	public String toString() {
		return new StringBuffer().append(this.getClass().getSimpleName()).append("[hint=")
				.append(hint).append(",size = ").append(texts.size()).append("]").toString();
	}
	
	public boolean isEmpty() {
		return texts.isEmpty();
	}

	public int size() {
		return texts.size();
	}
}
