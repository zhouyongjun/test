package com.zhou.core.http.server;
/**
 * ״̬
 * @author zhouyongjun
 *
 */
public enum State {
	INIT,
	START,
	STOP,
	DESTORY;
}
