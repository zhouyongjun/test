package com.zhou.core.telnet;

public interface TelnetHandle
{
  public String handle(String paramString);
}

