package com.zhou.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public final class StringUtils {
	/**
	 * ���List
	 * @param list
	 * @param separator
	 * @return
	 */
	public static final <T> String join(List<T> list,String separator)
	{
		StringBuilder sb = new StringBuilder();
		for(T str : list) 
		{
			sb.append(str).append(separator);
		}
		if (sb.length() > 0) sb.deleteCharAt(sb.length()-1);
		return sb.toString();
	}
	
	public static final <T> String join(T[] array,String separator)
	{
		StringBuilder sb = new StringBuilder();
		for(T str : array) 
		{
			sb.append(str).append(separator);
		}
		if (sb.length() > 0) sb.deleteCharAt(sb.length()-1);
		return sb.toString();
	}
	
	public static final <T, K, V> String join(String marker,Map<K,V> map,String separator1,String separator2)
	{
		StringBuilder sb = new StringBuilder();
		sb.append(marker).append("[");
		for(Entry<K, V> entry : map.entrySet()) 
		{
			sb.append(entry.getKey()).append(separator2).append(entry.getValue()).append(separator1);
		}
//		if (sb.length() > 0) sb.deleteCharAt(sb.length()-1);
		sb.append("]");
		return sb.toString();
	}
	
	public static final <T, K, V> String join(String marker,Map<K,V> map)
	{
		return join(marker, map, ";", ":");
	}
	
	/**
	 * �ж��Ƿ�Ϊ��
	 * @param str
	 * @return
	 */
	public static boolean isNull(String str){
		if (str == null || str.length() == 0) {
			return true;
		}
		return false;
	}

	public static boolean isBoolean(String attribute) {
		if (isNull(attribute)) return false;
		return attribute.toLowerCase().equals("true") || attribute.toLowerCase().equals("1");
	}

	public static int getInt(String attribute) {
		return Integer.parseInt(attribute);
	}

	public static long getLong(String attribute) {
		return Long.parseLong(attribute);
	}
	

	public static String toStringOfThrowable(Throwable throwable)
	{
		ByteArrayOutputStream ops = null;
		PrintWriter pw = null;
		String error = null;
		try {
			ops = new ByteArrayOutputStream(1024);
			pw = new PrintWriter(ops);
			throwable.printStackTrace(pw);
			pw.flush();
			error = ops.toString();
		} catch (Exception e) {}
		finally
		{
				try {
					if (ops != null)ops.close();
					if (pw!=null)pw.close();
				} catch (IOException e) {}
		}
		return error;
	}
}
