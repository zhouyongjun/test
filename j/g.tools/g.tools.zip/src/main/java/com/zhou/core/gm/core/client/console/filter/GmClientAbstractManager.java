package  com.zhou.core.gm.core.client.console.filter;

public abstract class GmClientAbstractManager{
	
	public GmClientAbstractManager() {
		
	}
	/**
	 * ע��
	 */
	public abstract void registerAllHandles();
	
}
