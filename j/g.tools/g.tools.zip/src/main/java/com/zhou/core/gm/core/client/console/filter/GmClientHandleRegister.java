package com.zhou.core.gm.core.client.console.filter;

public interface GmClientHandleRegister {
	void registerAllHandles();
}
