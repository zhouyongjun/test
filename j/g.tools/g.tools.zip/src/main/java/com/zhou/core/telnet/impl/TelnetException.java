package com.zhou.core.telnet.impl;

public class TelnetException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	  public TelnetException(String paramString)
	  {
	    super(paramString);
	  }

}
