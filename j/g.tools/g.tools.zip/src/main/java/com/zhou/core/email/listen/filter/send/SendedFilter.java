package com.zhou.core.email.listen.filter.send;

import com.zhou.core.email.EmailFilter;

public interface SendedFilter extends EmailFilter{

}
