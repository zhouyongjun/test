package com.zhou.core.common;

import com.zhou.util.CParam;
import com.zhou.util.CResult;

public interface CDailyable {
	CResult daily(CParam param);
}
