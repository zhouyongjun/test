
package com.zhou.core.esb.exception;

public class EsbException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5153612666889512262L;

}
