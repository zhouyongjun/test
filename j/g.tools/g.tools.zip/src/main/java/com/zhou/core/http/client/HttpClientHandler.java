package com.zhou.core.http.client;

import org.apache.http.NameValuePair;
/**
 * http�ͻ�����������
 * @author zhouyongjun
 *
 */
public interface HttpClientHandler {
	String handle(String url,NameValuePair... pairs) throws Exception;
	
}
