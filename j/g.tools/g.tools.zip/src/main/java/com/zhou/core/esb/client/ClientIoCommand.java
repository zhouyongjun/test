package com.zhou.core.esb.client;

import org.apache.mina.core.session.IoSession;
import org.apache.mina.handler.chain.IoHandlerCommand;

public class ClientIoCommand implements IoHandlerCommand{

	@Override
	public void execute(NextCommand next, IoSession session, Object message)
			throws Exception {
		// TODO Auto-generated method stub
		
	}

}
