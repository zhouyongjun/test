package com.zhou.core.common;

import com.zhou.util.CParam;
import com.zhou.util.CResult;
/**
 * tickִ��
 * @author zhouyongjun
 *
 */
public interface CTickable {
	CResult tick(CParam param);
}
