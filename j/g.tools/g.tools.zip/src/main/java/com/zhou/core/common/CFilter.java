package com.zhou.core.common;

import com.zhou.util.CParam;
import com.zhou.util.CResult;
/**
 * ������
 * @author zhouyongjun
 *
 */
public interface CFilter {
	CResult filter(CParam param);
}
