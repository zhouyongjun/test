package com.zhou.study.nio.example.constant;

/**
 * Created by jason-geng on 8/16/17.
 */
public interface HttpConstant {

    String[] HOSTS = {"www.baidu.com", "www.weibo.com", "www.sina.com"};

    int PORT = 80;
}
