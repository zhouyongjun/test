package com.zhou.study.dbcp2;


public class Dbcp2Main {
	DBConfig config ;
	public static void main(String[] args) {
		Dbcp2Util.update("update memory_data set energy_minute_count= 5442;");
	}
 
	

}
